<?php include "includes/header.php" ?>
<!--====== Page Banner PART START ======-->

<section class="page_banner bg_cover" style="background-image: url(assets/images/about_bg.jpg)">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="banner_content text-center">
                    <h4 class="title">Chapters</h4>
                    <ul class="breadcrumb justify-content-center">
                        <li><a href="#">Home</a></li>
                        <li><a class="active" href="#">Chapters</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="blog_area pt-40 pb-100">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-12 col-md-12">
                <div class="courses_curriculum mt-50">
                    <div class="courses_top_bar d-sm-flex justify-content-between align-items-center">
                        <div class="courses_title">
                            <h4 class="courses_details_title">Life Science</h4>
                        </div>
                        <div class="courses_meta">
                            <ul class="meta">
                                <li><i class="fa fa-files-o"></i> 23 Lectures</li>
                                <!-- <li><i class="fa fa-clock-o"></i> 2 Weeks</li> -->
                            </ul>
                        </div>
                    </div>

                    <div class="accordion" id="accordionExample">
                        <div class="card">
                            <div class="card-header" id="headingOne">
                                <a href="#" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne" class="collapsed">Chapter-1: ପୋଷଣ (Nutrition)</a>
                            </div>

                            <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample" style="">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="curriculum_content">
                                                <iframe width="100%" height="200" src="https://www.youtube.com/embed/DZ0YCDSO0gg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                                <div class="curriculum_list">
                                                    <span><strong>ପୋଷଣ (Nutrition) || Part-1</strong></span>
                                                    <ul>
                                                        <li><a href="#"><i class="fa fa-download"></i> Download PDF</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="curriculum_content">
                                                <iframe width="100%" height="200" src="https://www.youtube.com/embed/RhAXvLBDJ_k" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                                <div class="curriculum_list">
                                                    <span><strong>ପୋଷଣ (Nutrition) || Part-2</strong></span>
                                                    <ul>
                                                        <li><a href="#"><i class="fa fa-download"></i> Download PDF</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="2">
                                <a href="#" data-toggle="collapse" data-target="#2" aria-expanded="false" aria-controls="22" class="collapsed">Chapter-2: ଶ୍ୱସନ (Respiration)</a>
                            </div>

                            <div id="22" class="collapse show" aria-labelledby="2" data-parent="#accordionExample" style="">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="curriculum_content">
                                                <iframe width="100%" height="200" src="https://www.youtube.com/embed/ubg3aGsBj_s" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                                <div class="curriculum_list">
                                                    <span><strong>ଶ୍ୱସନ (Respiration) || Part-1</strong></span>
                                                    <ul>
                                                        <li><a href="#"><i class="fa fa-download"></i> Download PDF</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="curriculum_content">
                                                <iframe width="100%" height="200" src="https://www.youtube.com/embed/RaA7pF0YZDc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                                <div class="curriculum_list">
                                                    <span><strong>ଶ୍ୱସନ (Respiration) || Part-2</strong></span>
                                                    <ul>
                                                        <li><a href="#"><i class="fa fa-download"></i> Download PDF</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--====== Page Banner PART ENDS ======-->
<?php include "includes/footer.php" ?>