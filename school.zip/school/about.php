<?php include "includes/header.php" ?>
<!--====== Page Banner PART START ======-->

<section class="page_banner bg_cover" style="background-image: url(assets/images/about_bg.jpg)">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="banner_content text-center">
                        <h4 class="title">About us</h4>
                        <ul class="breadcrumb justify-content-center">
                            <li><a href="#">Home</a></li>
                            <li><a class="active" href="#">About Us</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--====== Page Banner PART ENDS ======-->

    <!--====== About PART START ======-->

    <section class="about_area pt-80">
        <img class="shap_1" src="assets/images/shape/shape-1.png" alt="shape">
        <img class="shap_2" src="assets/images/shape/shape-2.png" alt="shape">
        <img class="shap_3" src="assets/images/shape/shape-3.png" alt="shape">
        <img class="shap_4" src="assets/images/shape/shape-4.png" alt="shape">
        
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="about_content mt-45">
                        <h3 class="about_title">We are the top learning platform</h3>
                        <p class="text">What do you think is better to receive after each lesson: a lovely looking badge or important skills you can immediately put into practice</p>
                        <p>What do you think is better to receive after each lesson: a lovely looking badge or important skills you can immediately put into practice? We thought you might choose the latter.</p>
                        <a href="#" class="main-btn">Learn More</a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="about_image mt-50">
                        <img src="assets/images/about-1.jpg" alt="about" class="about_image-1">
                        <img src="assets/images/about-2.jpg" alt="about" class="about_image-2">
                        <img src="assets/images/about-3.jpg" alt="about" class="about_image-3">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--====== About PART ENDS ======-->

    <!--====== Counter PART START ======-->

    <!-- <section class="counter_area pt-80 pb-130">
        <div class="container">
            <div class="row counter_wrapper">
                <div class="col-lg-3 col-sm-6 counter_col">
                    <div class="single_counter text-center mt-50">
                        <div class="counter_icon">
                            <div class="icon_wrapper">
                                <img src="assets/images/count_icon-1.png" alt="Icon">
                            </div>
                        </div>
                        <div class="counter_content">
                            <span class="cont"><span class="counter">78</span>+</span>
                            <p>University  Faculties</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 counter_col">
                    <div class="single_counter text-center mt-50">
                        <div class="counter_icon">
                            <div class="icon_wrapper">
                                <img src="assets/images/count_icon-2.png" alt="Icon">
                            </div>
                        </div>
                        <div class="counter_content">
                            <span class="cont"><span class="counter">5</span>k+</span>
                            <p>Total Students</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 counter_col">
                    <div class="single_counter text-center mt-50">
                        <div class="counter_icon">
                            <div class="icon_wrapper">
                                <img src="assets/images/count_icon-3.png" alt="Icon">
                            </div>
                        </div>
                        <div class="counter_content">
                            <span class="cont"><span class="counter">400</span>k</span>
                            <p>Library Books</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 counter_col">
                    <div class="single_counter text-center mt-50">
                        <div class="counter_icon">
                            <div class="icon_wrapper">
                                <img src="assets/images/count_icon-4.png" alt="Icon">
                            </div>
                        </div>
                        <div class="counter_content">
                            <span class="cont"><span class="counter">1200</span></span>
                            <p>Seminers Held</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->

    <!--====== Counter PART ENDS ======-->

    <!--====== About 2 PART START ======-->

    <section class="about_area_2 d-flex flex-wrap ">
        <div class="about_video bg_cover" style="background-image: url(assets/images/about_bg.jpg)">
            <div class="video">
                <a class="video_play" href="#"><i class="fa fa-play"></i></a>
            </div>
        </div>
        
        <div class="about_content_2">
            <div class="single_about_2 d-flex flex-wrap about_color_1">
                <div class="about_2_content">
                    <div class="about_2_content_wrapper">
                        <h4 class="title"><a href="#">Scholarships</a></h4>
                        <p>What do you think is better to receive after each lesson: a lovely looking </p>
                        <a href="#" class="main-btn">Learn More</a>
                    </div>
                </div>
                <div class="about_2_image bg_cover" style="background-image: url(assets/images/about-4.jpg)"></div>
            </div>
            
            <div class="single_about_2 d-flex flex-wrap about_color_2">
                <div class="about_2_content order-md-last">
                    <div class="about_2_content_wrapper">
                        <h4 class="title"><a href="#">Alumnai</a></h4>
                        <p>What do you think is better to receive after each lesson: a lovely looking </p>
                        <a href="#" class="main-btn">Learn More</a>
                    </div>
                </div>
                <div class="about_2_image bg_cover order-md-first" style="background-image: url(assets/images/about-5.jpg)"></div>
            </div>
        </div>
    </section>

    <!--====== About 2 PART ENDS ======-->

    <!--====== Why Choose Us PART START ======-->
    <?php include "includes/why-choose-us.php" ?>

    <!--====== Why Choose Us PART ENDS ======-->
    
    <!--====== Testimonial PART START ======-->

    <section class="testimonial_area pt-80 pb-130 bg_cover" style="background-image: url(assets/images/testimonial_bg.jpg)">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="testimonial_title mt-50">
                        <img src="assets/images/quota.png" alt="quota">
                        <h2 class="title">Success stories of students who took best from us</h2>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="testimonial_items mt-50">
                        <div class="single_testimonial">
                            <p>I found myself working in a true partnership that results in an incredible experience, and an end product that is the best. </p>
                            <h6 class="name">Arnold Holder</h6>
                            <span>Student, Language</span>
                        </div>
                        
                        <div class="single_testimonial">
                            <p>I found myself working in a true partnership that results in an incredible experience, and an end product that is the best. </p>
                            <h6 class="name">Arnold Holder</h6>
                            <span>Student, Language</span>
                        </div>
                        
                        <div class="single_testimonial">
                            <p>I found myself working in a true partnership that results in an incredible experience, and an end product that is the best. </p>
                            <h6 class="name">Arnold Holder</h6>
                            <span>Student, Language</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--====== Testimonial PART ENDS ======-->
    <?php include "includes/footer.php" ?>