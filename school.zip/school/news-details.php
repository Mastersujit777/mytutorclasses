<?php include "includes/header.php" ?>
 <!--====== Page Banner PART START ======-->

 <section class="page_banner bg_cover" style="background-image: url(assets/images/about_bg.jpg)">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="banner_content text-center">
                        <h4 class="title">News Details</h4>
                        <ul class="breadcrumb justify-content-center">
                            <li><a href="#">Home</a></li>
                            <li><a class="active" href="#">News Details</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--====== Page Banner PART ENDS ======-->
    
    <!--====== Blog List Page PART START ======-->

    <section class="blog_details_page pt-80 pb-130">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="blog_details mt-50">
                        <div class="details_image">
                            <img src="assets/images/blog-list-1.jpg" alt="blog">
                        </div>
                        <div class="details_content">
                             <span class="date"><span>25</span>  June</span>
                             
                             <div class="blog_content_wrapper">
                                <ul class="blog_meta">
                                    <li><a href="#">Admin(News From NDTV)</a></li>
                                    <li><a href="#">25 June 2021</a></li>
                                </ul>
                                <h4 class="blog_title">BSE Odisha 10th Result 2021 Live Updates</h4>
                            </div>
                        </div>
                        <p>Odisha HSC 10th result will be announced today. Board of Secondary Education (BSE), Odisha will announce matric results this evening by 6 pm. The result will be released on the board's official website, '<a href="http://bseodisha.nic.in/">bseodisha.nic.in</a>', and official results portal, '<a href="https://orissaresults.nic.in/">orissaresults.nic.in</a>'. Odisha matric results will also be available on private result portals and through SMS. The Board couldn’t conduct the examinations this year in the wake of COVID-19. This year nearly five lakh students are expecting their BSE HSC results prepared based on the evaluation formula.</p>
                        <p>As per the criteria released by the board, the 10th Class result 2021 Odisha board will be released on the basis of Class 9 and Class 10 marks. The board will also consider the performance of a school in the past four years’ HSC exam. For “regular” and “quasi-regular” students, marks will be given on the basis of their performance in the half-yearly, annual exams of Class 9 and practice tests held in Class 10. While 40 per cent weightage will be given to highest marks obtained in Class 9 exams in each subject, the remaining 60 per cent weightage will come from practice tests conducted in Class 10.</p>
                        <blockquote class="blockquote">
                            <i class="fa fa-quote-right"></i>
                            <p>“In case any candidate has appeared in only one practice test, then 70 per cent weightage will be given in the mark secured in Class 9 exams (half yearly and annual),” the board said.</p>
                        </blockquote>
                        <p>Despite the pandemic, students are not able to appear in the exam. But somehow the Odisha Government tries to declare the result based on their past records and hard work.</p>
                        <p>This will satisfy the student's mind and help them to have a great future ahead and motivate them to study well and work hard for their beautiful future.</p>

                    </div>
                    <!-- <div class="blog_details_share d-flex">
                        <span>Share :</span>
                        <ul class="social">
                            <li><a href="#"><i class="fa fa-facebook-square"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter-square"></i></a></li>
                            <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin-square"></i></a></li>
                        </ul>
                    </div> -->
                    <!-- <div class="blog_details_comment">
                        <div class="blog_comment_items">
                            <h4 class="blog_details_comment_title">(03) Comment</h4>
                            <ul>
                                <li>
                                    <div class="single_comment d-sm-flex">
                                        <div class="comment_author">
                                            <img src="assets/images/author-4.jpg" alt="Author">
                                        </div>
                                        <div class="comment_content media-body">
                                            <h5 class="author_name">Kosmi Kotalia</h5>
                                            <p>There are many variations of passages of Lorem Ipsum available, but the majority some form, by injected humour, or randomised words which.</p>
                                            <ul class="commtent_meta">
                                                <li><a href="#"><i class="fa fa-retweet"></i> Repost</a></li>
                                                <li><a href="#"><i class="fa fa-reply"></i> Replay</a></li>
                                                <li><a href="#"><i class="fa fa-clock-o"></i> 39 minits ago</a></li>
                                            </ul>
                                        </div>
                                    </div> 
                                    <ul class="reply_comment">
                                        <li>
                                            <div class="single_comment d-sm-flex">
                                                <div class="comment_author">
                                                    <img src="assets/images/author-5.jpg" alt="Author">
                                                </div>
                                                <div class="comment_content media-body">
                                                    <h5 class="author_name">Kosmi Kotalia</h5>
                                                    <p>There are many variations of passages of Lorem Ipsum available, but the majority some form, by injected humour, or randomised words which.</p>
                                                    <ul class="commtent_meta">
                                                        <li><a href="#"><i class="fa fa-retweet"></i> Repost</a></li>
                                                        <li><a href="#"><i class="fa fa-reply"></i> Replay</a></li>
                                                        <li><a href="#"><i class="fa fa-clock-o"></i> 39 minits ago</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <div class="single_comment d-sm-flex">
                                        <div class="comment_author">
                                            <img src="assets/images/author-6.jpg" alt="Author">
                                        </div>
                                        <div class="comment_content media-body">
                                            <h5 class="author_name">Kosmi Kotalia</h5>
                                            <p>There are many variations of passages of Lorem Ipsum available, but the majority some form, by injected humour, or randomised words which.</p>
                                            <ul class="commtent_meta">
                                                <li><a href="#"><i class="fa fa-retweet"></i> Repost</a></li>
                                                <li><a href="#"><i class="fa fa-reply"></i> Replay</a></li>
                                                <li><a href="#"><i class="fa fa-clock-o"></i> 39 minits ago</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div class="blog_comment_form mt-45">
                            <h4 class="blog_details_comment_title pb-15">Leave Comment</h4>
                            <form action="#">
                                <div class="single_form">
                                    <input type="text" placeholder="Name">
                                </div> 
                                <div class="single_form">
                                    <input type="email" placeholder="Email">
                                </div> 
                                <div class="single_form">
                                    <textarea placeholder="Comment"></textarea>
                                </div> 
                                <div class="single_form">
                                    <button class="main-btn">Post Comment</button>
                                </div> 
                            </form>
                        </div>
                    </div> -->
                </div>
                <!-- <div class="col-lg-4">
                    <div class="sidebar mt-50">
                        <div class="sidebar_search">
                            <form action="#">
                                <input type="text" placeholder="Search">
                                <button><i class="fa fa-search"></i></button>
                            </form>
                        </div>
                        
                        <div class="sidebar_post mt-30">
                            <h5 class="sidebar_title">Popular Posts</h5>
                            <ul>
                                <li>
                                    <div class="single_sidebar_post d-flex mt-30">
                                        <div class="post_image">
                                            <img src="assets/images/blog-1.jpg" alt="blog">
                                        </div>
                                        <div class="post_content media-body">
                                            <h6 class="title"><a href="#">Cupidatat non proident sunt culpa officia deserunt</a></h6>
                                            <p class="date">05 Oct 2019</p>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="single_sidebar_post d-flex mt-30">
                                        <div class="post_image">
                                            <img src="assets/images/blog-2.jpg" alt="blog">
                                        </div>
                                        <div class="post_content media-body">
                                            <h6 class="title"><a href="#">Cupidatat non proident sunt culpa officia deserunt</a></h6>
                                            <p class="date">05 Oct 2019</p>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="single_sidebar_post d-flex mt-30">
                                        <div class="post_image">
                                            <img src="assets/images/blog-3.jpg" alt="blog">
                                        </div>
                                        <div class="post_content media-body">
                                            <h6 class="title"><a href="#">Cupidatat non proident sunt culpa officia deserunt</a></h6>
                                            <p class="date">05 Oct 2019</p>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        
                        <div class="sidebar_list mt-30">
                            <h5 class="sidebar_title">Archives</h5>
                            
                            <ul class="archives_list">
                                <li><a href="#"><i class="fa fa-angle-right"></i> Jan 2019 <span>(10)</span></a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i> Feb 2019 <span>(02)</span></a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i> March 2019 <span>(0)</span></a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i> April 2019 <span>(1)</span></a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i> May 2019 <span>(5)</span></a></li>
                            </ul>
                        </div>
                        
                        <div class="sidebar_tag mt-30">
                            <h5 class="sidebar_title">Tags</h5>
                            
                            <ul class="archives_tag">
                                <li><a href="#">Technology</a></li>
                                <li><a href="#">Business</a></li>
                                <li><a href="#">LMS</a></li>
                                <li><a href="#">Learning</a></li>
                                <li><a href="#">Social</a></li>
                                <li><a href="#">Course</a></li>
                            </ul>
                        </div>
                    </div>
                </div> -->
            </div>
        </div>
    </section>

    <!--====== Blog List Page PART ENDS ======-->
<?php include "includes/footer.php" ?>