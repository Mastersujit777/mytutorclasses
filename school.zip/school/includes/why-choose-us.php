<section class="why_choose_area pt-120 pb-130">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="why_choose_content">
                        <div class="section_title pb-20">
                            <h3 class="main_title">Why choose us?</h3>
                            <p>What do you think is better to receive after each lesson: a lovely looking badge or important skills you can immediately put into practice.</p>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 choose_col">
                                <div class="single_choose mt-30">
                                    <div class="choose_icon">
                                        <img src="assets/images/choose_icon-1.png" alt="Icon">
                                    </div>
                                    <div class="choose_content">
                                        <h5 class="title"><a href="#">Digital Library</a></h5>
                                        <p>We have online library where you will get lifetime free access to e-books, videos and Study materials.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 choose_col">
                                <div class="single_choose mt-30">
                                    <div class="choose_icon">
                                        <img src="assets/images/choose_icon-2.png" alt="Icon">
                                    </div>
                                    <div class="choose_content">
                                        <h5 class="title"><a href="#">Top Teachers</a></h5>
                                        <p>We have a panel of qualified teachers who deliver online classes, doubt clearing session also prepare the study materials.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 choose_col">
                                <div class="single_choose mt-30">
                                    <div class="choose_icon">
                                        <img src="assets/images/choose_icon-3.png" alt="Icon">
                                    </div>
                                    <div class="choose_content">
                                        <h5 class="title"><a href="#">Larger Community</a></h5>
                                        <p>We have larger community of teachers in different subject area with whom you can clarify your doubts, they will provide solution in easier possible way.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 choose_col">
                                <div class="single_choose mt-30">
                                    <div class="choose_icon">
                                        <img src="assets/images/choose_icon-4.png" alt="Icon">
                                    </div>
                                    <div class="choose_content">
                                        <h5 class="title"><a href="#">Career Counselling</a></h5>
                                        <p>We have experts who are excellent in their academics and always updated with current possible scenarios who can guide you in your career path.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="why_choose_image d-none d-lg-table">
            <div class="image">
                <img src="assets/images/choose_bg.jpg" alt="">
            </div>
        </div>
    </section>