  <!--====== Footer PART START ======-->

  <footer class="footer_area bg_cover" style="background-image: url(assets/images/footer_bg.jpg)">
        <div class="footer_widget pt-20 pb-40">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-sm-6">
                        <div class="footer_about mt-50">
                            <a href="#"><img src="assets/images/logo.png" alt="logo"></a>
                            
                            <p>Lorem ipsum dolor sit amet dolor, con sect etur adipiscing elitorem ipsum dolorsit amet dolor, con sectetur con sectetur adipisci adipiscing.</p>
                            
                            <ul class="footer_social">
                                <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                <li><a href="#"><i class="fa fa-pinterest-p"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-9">
                        <div class="footer_widget_wrapper d-flex flex-wrap">
                            <div class="footer_link mt-50">
                                <h5 class="footer_title">Quick Links</h5>

                                <div class="footer_link_wrapper d-flex">
                                    <ul class="link">
                                        <li><a href="#">Home</a></li>
                                        <li><a href="#">About us</a></li>
                                        <li><a href="#">Education</a></li>
                                        <li><a href="#">Our Events</a></li>
                                        <li><a href="#">Our Packages</a></li>
                                    </ul>
                                    <ul class="link">
                                        <li><a href="#">Our Team</a></li>
                                        <li><a href="#">Latest News</a></li>
                                        <li><a href="#">Privacy Policy</a></li>
                                        <li><a href="#">Terms & Condations</a></li>
                                        <li><a href="#">Contact Us</a></li>
                                    </ul>
                                </div>
                            </div>

                            <div class="footer_contact mt-50">
                                <h5 class="footer_title">Contact</h5>
                                
                                <ul class="contact">
                                    <li>Location : Bhubaneswar, odisha</li>
                                    <li>Emal : info@mytutorclasses.com</li>
                                    <li>Phone : +(91)933 733 6750</li>
                                    <li><a href="#">View us on Google </a></li>
                                    <li></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="footer_copyright">
            <div class="container">
                <div class="footer_copyright_wrapper text-center d-md-flex justify-content-between">
                    <div class="copyright">
                        <p>Designed & Developed By <a href="www.codenxtlabs.com">CodeNXTlabs</a></p>
                    </div>
                    <div class="copyright">
                        <p>&copy; Copyrights 2021 MyTutorClasses All rights reserved. </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!--====== Footer PART ENDS ======-->
    
    <!--====== BACK TOP TOP PART START ======-->

    <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

    <!--====== BACK TOP TOP PART ENDS ======-->

    



    <!--====== jquery js ======-->
    <script src="assets/js/vendor/modernizr-3.6.0.min.js"></script>
    <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>

    <!--====== Bootstrap js ======-->
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/popper.min.js"></script>

    <!--====== Slick js ======-->
    <script src="assets/js/slick.min.js"></script>

    <!--====== Magnific Popup js ======-->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>

    <!--====== Counter Up js ======-->
    <script src="assets/js/waypoints.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>

    <!--====== Nice Select js ======-->
    <script src="assets/js/jquery.nice-select.min.js"></script>
    
    <!--====== Count Down js ======-->
    <script src="assets/js/jquery.countdown.min.js"></script>
    
    <!--====== Appear js ======-->
    <script src="assets/js/jquery.appear.min.js"></script>

    <!--====== Main js ======-->
    <script src="assets/js/main.js"></script>

</body>


</html>
