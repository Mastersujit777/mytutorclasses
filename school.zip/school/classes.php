<?php include "includes/header.php" ?>
<!--====== Page Banner PART START ======-->

<section class="page_banner bg_cover" style="background-image: url(assets/images/about_bg.jpg)">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="banner_content text-center">
                    <h4 class="title">Classes/Courses</h4>
                    <ul class="breadcrumb justify-content-center">
                        <li><a href="#">Home</a></li>
                        <li><a class="active" href="#">Classes</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="blog_area pt-50 pb-100">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-4 col-md-7">
                <div class="single_blog mt-30">
                    <div class="blog_image">
                        <img src="assets/images/class-10.jpg" alt="blog">
                    </div>
                    <div class="blog_content">
                        
                        <div class="blog_content_wrapper">
                            <h4 class="blog_title"><a href="subjects.php">Class-10</a></h4>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-7">
                <div class="single_blog mt-30">
                    <div class="blog_image">
                        <img src="assets/images/class-9.jpg" alt="blog">
                    </div>
                    <div class="blog_content">
                        
                        <div class="blog_content_wrapper">
                            <h4 class="blog_title"><a href="#">Class-9</a></h4>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-7">
                <div class="single_blog mt-30">
                    <div class="blog_image">
                        <img src="assets/images/class-8.jpg" alt="blog">
                    </div>
                    <div class="blog_content">
                        
                        <div class="blog_content_wrapper">
                            <h4 class="blog_title"><a href="#">Class-8</a></h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--====== Page Banner PART ENDS ======-->
<?php include "includes/footer.php" ?>