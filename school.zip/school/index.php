 <?php include "includes/header.php" ?>
 <!--====== Slider PART START ======-->

 <section class="slider_area slider-active">
        <div class="single_slider bg_cover d-flex align-items-center" style="background-image: url(assets/images/slider-1.jpg)">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="slider_content text-center">
                            <!-- <h4 class="sub_title" data-animation="fadeInUp" data-delay="0.2s">Odisha Class 10 Result To Be Declared Today </h4> -->
                            <h2 class="main_title" data-animation="fadeInUp" data-delay="0.5s">BSE Odisha <span>10th Result</span> 2021</h2>
                            <p data-animation="fadeInUp" data-delay="0.8s">Odisha Board of Secondary Education ( BSE) is announcing its 10th result today by 4 pm on its official website <a href="http://bseodisha.nic.in/" target="_blank">bseodisha.nic.in</a>. Students can check their result on the mentioned website from 6 pm onwards and can wait in case of technical issue or traffic on the website.</p>
                            <a class="main-btn" href="news-details.php" data-animation="fadeInUp" data-delay="1.1s">Check Result</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="single_slider bg_cover d-flex align-items-center" style="background-image: url(assets/images/slider-1.jpg)">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="slider_content text-center">
                            <h4 class="sub_title" data-animation="fadeInUp" data-delay="0.2s">Welcome to MyTutorClasses </h4>
                            <h2 class="main_title" data-animation="fadeInUp" data-delay="0.5s">Personalised <span>Learning</span> Platform</h2>
                            <p data-animation="fadeInUp" data-delay="0.8s">What do you think is better to receive after each lesson: a lovely looking badge or important skills you can immediately put into practice.</p>
                            <a class="main-btn" href="#" data-animation="fadeInUp" data-delay="1.1s">Learn More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="single_slider bg_cover d-flex align-items-center" style="background-image: url(assets/images/slider-3.jpg)">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="slider_content text-center">
                            <h4 class="sub_title" data-animation="fadeInUp" data-delay="0.2s">Welcome to your </h4>
                            <h2 class="main_title" data-animation="fadeInUp" data-delay="0.5s">First <span>Learning</span> Platform</h2>
                            <p data-animation="fadeInUp" data-delay="0.8s">We have online library where you will get lifetime free access to e-books, videos and Study materials.</p>
                            <a class="main-btn" href="#" data-animation="fadeInUp" data-delay="1.1s">Learn More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--====== Slider PART ENDS ======-->

    <!--====== Features PART START ======-->

    <section class="features_area ">
        <div class="container">
            <div class="features_wrapper">
                <div class="row no-gutters">
                    <div class="col-md-4 features_col">
                        <div class="single_features text-center">
                            <div class="features_icon">
                                <img src="assets/images/f-icon-1.png" alt="Icon">
                            </div>
                            <div class="features_content">
                                <h4 class="features_title"><a href="#">Quality Teachers</a></h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 features_col">
                        <div class="single_features text-center">
                            <div class="features_icon">
                                <img src="assets/images/f-icon-2.png" alt="Icon">
                            </div>
                            <div class="features_content">
                                <h4 class="features_title"><a href="#">Best Curriculam</a></h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 features_col">
                        <div class="single_features text-center">
                            <div class="features_icon">
                                <img src="assets/images/f-icon-3.png" alt="Icon">
                            </div>
                            <div class="features_content">
                                <h4 class="features_title"><a href="#">Global Recognition</a></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--====== Features PART ENDS ======-->


    <!--====== Courses PART START ======-->

    <section class="courses_area pt-60 pb-60">
        
        <img class="shape-1" src="assets/images/shape/shape-1.png" alt="shape">
        <img class="shape-2" src="assets/images/shape/shape-2.png" alt="shape">
        <img class="shape-3" src="assets/images/shape/shape-3.png" alt="shape">
        <img class="shape-4" src="assets/images/shape/shape-4.png" alt="shape">
        <img class="shape-5" src="assets/images/shape/shape-5.png" alt="shape">
        
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="section_title text-center pb-20">
                        <h3 class="main_title">Featured Courses</h3>
                        <p>What do you think is better to receive after each lesson: a lovely looking badge or important skills you can immediately put into practice.</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3 col-sm-6">
                    <div class="single_courses mt-30">
                        <div class="courses_image">
                        <iframe width="100%" height="135" src="https://www.youtube.com/embed/ubg3aGsBj_s" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                        <div class="courses_content ">
                            <ul class="tag">
                                <li><a href="#">Class-10</a></li>
                                <li><a href="#">Science</a></li>
                            </ul>
                            <div class="courses_author d-flex">
                                <div class="author_name media-body">
                                    <a href="#">Chapter-1</a>
                                </div>
                            </div>
                            <h4 class="title"><a href="#">Respiration || Swashana (Part-1) </a></h4>
                            <div class="meta d-flex justify-content-between">
                                <ul>
                                    <li><a href="https://www.youtube.com/channel/UCl0cIBpbFpm9O5wCIN5bSvw"><i class="fa fa-user-o"></i> S. S tutorial</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="single_courses mt-30">
                        <div class="courses_image">
                        <iframe width="100%" height="135" src="https://www.youtube.com/embed/RaA7pF0YZDc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                        <div class="courses_content ">
                            <ul class="tag">
                                <li><a href="#">Class-10</a></li>
                                <li><a href="#">Science</a></li>
                            </ul>
                            <div class="courses_author d-flex">
                                <div class="author_name media-body">
                                    <a href="#">Chapter-2</a>
                                </div>
                            </div>
                            <h4 class="title"><a href="#">Respiration || Swashana (Part-2) </a></h4>
                            <div class="meta d-flex justify-content-between">
                                <ul>
                                    <li><a href="https://www.youtube.com/channel/UCl0cIBpbFpm9O5wCIN5bSvw"><i class="fa fa-user-o"></i> S. S tutorial</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-3 col-sm-6">
                    <div class="single_courses mt-30">
                        <div class="courses_image">
                        <iframe width="100%" height="135" src="https://www.youtube.com/embed/RaA7pF0YZDc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                        <div class="courses_content ">
                            <ul class="tag">
                                <li><a href="#">Class-10</a></li>
                                <li><a href="#">Science</a></li>
                            </ul>
                            <div class="courses_author d-flex">
                                <div class="author_name media-body">
                                    <a href="#">Chapter-2</a>
                                </div>
                            </div>
                            <h4 class="title"><a href="#">Respiration || Swashana (Part-2) </a></h4>
                            <div class="meta d-flex justify-content-between">
                                <ul>
                                    <li><a href="https://www.youtube.com/channel/UCl0cIBpbFpm9O5wCIN5bSvw"><i class="fa fa-user-o"></i> S. S tutorial</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="single_courses mt-30">
                        <div class="courses_image">
                        <iframe width="100%" height="135" src="https://www.youtube.com/embed/RaA7pF0YZDc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                        <div class="courses_content ">
                            <ul class="tag">
                                <li><a href="#">Class-10</a></li>
                                <li><a href="#">Science</a></li>
                            </ul>
                            <div class="courses_author d-flex">
                                <div class="author_name media-body">
                                    <a href="#">Chapter-2</a>
                                </div>
                            </div>
                            <h4 class="title"><a href="#">Respiration || Swashana (Part-2) </a></h4>
                            <div class="meta d-flex justify-content-between">
                                <ul>
                                    <li><a href="https://www.youtube.com/channel/UCl0cIBpbFpm9O5wCIN5bSvw"><i class="fa fa-user-o"></i> S. S tutorial</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <p class="text-center">
                        <a class="main-btn" href="classes.php" data-animation="fadeInUp" data-delay="1.1s">Load More</a>
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!--====== Courses PART ENDS ======-->


    <!--====== Program PART START ======-->

    <section class="program_area pt-60">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="section_title section_title_2 text-center pb-50">
                        <h3 class="main_title">Our Subjects</h3>
                        <p>What do you think is better to receive after each lesson: a lovely looking badge or important skills you can immediately put into practice.</p>
                    </div>
                </div>
            </div>
            <div class="row no-gutters program_wrapper">
                <div class="col-lg-4 col-md-6 program_col">
                    <div class="single_program program_color-1 d-flex flex-wrap">
                        <div class="program_icon">
                            <div class="icon_wrapper">
                                <img src="assets/images/p-icon-1.png" alt="Icon">
                            </div>
                        </div>
                        <div class="program_content">
                            <div class="content_wrapper">
                                <h5 class="title"><a href="#">Mathmatics</a></h5>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 program_col">
                    <div class="single_program program_color-2 d-flex flex-wrap program_4">
                        <div class="program_icon">
                            <div class="icon_wrapper">
                                <img src="assets/images/p-icon-2.png" alt="Icon">
                            </div>
                        </div>
                        <div class="program_content">
                            <div class="content_wrapper">
                                <h5 class="title"><a href="#">Science</a></h5>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 program_col">
                    <div class="single_program program_color-3 d-flex flex-wrap program_3">
                        <div class="program_icon">
                            <div class="icon_wrapper">
                                <img src="assets/images/p-icon-3.png" alt="Icon">
                            </div>
                        </div>
                        <div class="program_content">
                            <div class="content_wrapper">
                                <h5 class="title"><a href="#">History & Civics</a></h5>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 program_col">
                    <div class="single_program program_color-4 d-flex flex-wrap program_2 program_3 program_4">
                        <div class="program_icon">
                            <div class="icon_wrapper">
                                <img src="assets/images/p-icon-4.png" alt="Icon">
                            </div>
                        </div>
                        <div class="program_content">
                            <div class="content_wrapper">
                                <h5 class="title"><a href="#">Geography & Economics</a></h5>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 program_col">
                    <div class="single_program program_color-5 d-flex flex-wrap program_2">
                        <div class="program_icon">
                            <div class="icon_wrapper">
                                <img src="assets/images/p-icon-5.png" alt="Icon">
                            </div>
                        </div>
                        <div class="program_content">
                            <div class="content_wrapper">
                                <h5 class="title"><a href="#">Literature</a></h5>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 program_col">
                    <div class="single_program program_color-6 d-flex flex-wrap program_2 program_4">
                        <div class="program_icon">
                            <div class="icon_wrapper">
                                <img src="assets/images/p-icon-6.png" alt="Icon">
                            </div>
                        </div>
                        <div class="program_content">
                            <div class="content_wrapper">
                                <h5 class="title"><a href="#">Computer</a></h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--====== Program PART ENDS ======-->

    <!--====== Why Choose Us PART START ======-->

    <?php include "includes/why-choose-us.php" ?>

    <!--====== Why Choose Us PART ENDS ======-->

    <?php include "includes/footer.php" ?>