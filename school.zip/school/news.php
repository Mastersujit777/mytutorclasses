<?php include "includes/header.php" ?>
<!--====== Page Banner PART START ======-->

<section class="page_banner bg_cover" style="background-image: url(assets/images/about_bg.jpg)">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="banner_content text-center">
                        <h4 class="title">News List</h4>
                        <ul class="breadcrumb justify-content-center">
                            <li><a href="/">Home</a></li>
                            <li><a class="active" href="#">News</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--====== Page Banner PART ENDS ======-->
    
    <!--====== Blog List Page PART START ======-->

    <section class="blog_list_page pt-80 pb-130">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="single_blog_list mt-50">
                        <div class="blog_list_image">
                            <img src="assets/images/blog-list-1.jpg" alt="blog">
                        </div>
                        <div class="blog_list_content">
                            <span class="date"><span>25</span>  June</span>
                            
                            <div class="blog_content_wrapper">
                                <ul class="blog_meta">
                                    <li><a href="#">Admin(News From NDTV)</a></li>
                                    <li><a href="#">25 June 2021</a></li>
                                </ul>
                                <h4 class="blog_title"><a href="news-details.php">BSE Odisha 10th Result 2021 Live Updates</a></h4>
                                <p>BSE Odisha 10th Result 2021 Live Updates: Odisha Class 10 Result To Be Declared Today. This year nearly five lakh students are expecting their BSE HSC results prepared based on the evaluation formula.</p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- <ul class="pagination justify-content-center">
                        <li><a href="#"><i class="fa fa-angle-left"></i></a></li>
                        <li><a class="active" href="#">1</a></li>
                        <li><a href="#">2</a></li>
                        <li><a href="#">3</a></li>
                        <li><a href="#"><i class="fa fa-angle-right"></i></a></li>
                    </ul> -->
                </div>
                <!-- <div class="col-lg-4">
                    <div class="sidebar mt-50">
                        <div class="sidebar_search">
                            <form action="#">
                                <input type="text" placeholder="Search">
                                <button><i class="fa fa-search"></i></button>
                            </form>
                        </div>
                        
                        <div class="sidebar_post mt-30">
                            <h5 class="sidebar_title">Popular Posts</h5>
                            <ul>
                                <li>
                                    <div class="single_sidebar_post d-flex mt-30">
                                        <div class="post_image">
                                            <img src="assets/images/blog-1.jpg" alt="blog">
                                        </div>
                                        <div class="post_content media-body">
                                            <h6 class="title"><a href="#">Cupidatat non proident sunt culpa officia deserunt</a></h6>
                                            <p class="date">05 Oct 2019</p>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="single_sidebar_post d-flex mt-30">
                                        <div class="post_image">
                                            <img src="assets/images/blog-2.jpg" alt="blog">
                                        </div>
                                        <div class="post_content media-body">
                                            <h6 class="title"><a href="#">Cupidatat non proident sunt culpa officia deserunt</a></h6>
                                            <p class="date">05 Oct 2019</p>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="single_sidebar_post d-flex mt-30">
                                        <div class="post_image">
                                            <img src="assets/images/blog-3.jpg" alt="blog">
                                        </div>
                                        <div class="post_content media-body">
                                            <h6 class="title"><a href="#">Cupidatat non proident sunt culpa officia deserunt</a></h6>
                                            <p class="date">05 Oct 2019</p>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        
                        <div class="sidebar_list mt-30">
                            <h5 class="sidebar_title">Archives</h5>
                            
                            <ul class="archives_list">
                                <li><a href="#"><i class="fa fa-angle-right"></i> Jan 2019 <span>(10)</span></a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i> Feb 2019 <span>(02)</span></a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i> March 2019 <span>(0)</span></a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i> April 2019 <span>(1)</span></a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i> May 2019 <span>(5)</span></a></li>
                            </ul>
                        </div>
                        
                        <div class="sidebar_tag mt-30">
                            <h5 class="sidebar_title">Tags</h5>
                            
                            <ul class="archives_tag">
                                <li><a href="#">Technology</a></li>
                                <li><a href="#">Business</a></li>
                                <li><a href="#">LMS</a></li>
                                <li><a href="#">Learning</a></li>
                                <li><a href="#">Social</a></li>
                                <li><a href="#">Course</a></li>
                            </ul>
                        </div>
                    </div>
                </div> -->
            </div>
        </div>
    </section>

    <!--====== Blog List Page PART ENDS ======-->
<?php include "includes/footer.php" ?>