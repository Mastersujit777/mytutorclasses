<?php include "includes/header.php" ?>
<!--====== Page Banner PART START ======-->

<section class="page_banner bg_cover" style="background-image: url(assets/images/about_bg.jpg)">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="banner_content text-center">
                    <h4 class="title">Contact Us</h4>
                    <ul class="breadcrumb justify-content-center">
                        <li><a href="#">Home</a></li>
                        <li><a class="active" href="#">Contact</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<!--====== Page Banner PART ENDS ======-->

<!--====== CONTACT PART START ======-->

<section class="contact_area pt-80 pb-130">
    <div class="services_shape_1" style="background-image: url(assets/images/shape/shape-12.html)"></div>
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <div class="contact_form mt-40">                        
                    
                    <div class="row">
                        <div class="col-lg-10">
                            <div class="section_title pb-30">
                                <h3 class="main_title">Get in touch</h3>
                                <p>What do you think is better to receive after each lesson: a lovely looking badge or important skills you can immediately put into practice.</p>
                            </div>
                        </div>
                    </div>
                    
                    <form action="contact.php" method="POST">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="single_form">
                                    <input type="text" placeholder="Name">
                                </div> <!-- single form -->
                            </div>
                            <div class="col-md-6">
                                <div class="single_form">
                                    <input type="email" placeholder="Email">
                                </div> <!-- single form -->
                            </div>
                            <div class="col-md-6">
                                <div class="single_form">
                                    <input type="text" placeholder="Subject">
                                </div> <!-- single form -->
                            </div>
                            <div class="col-md-6">
                                <div class="single_form">
                                    <input type="text" placeholder="Number">
                                </div> <!-- single form -->
                            </div>
                            <div class="col-md-12">
                                <div class="single_form">
                                    <textarea placeholder="Massage"></textarea>
                                </div> <!-- single form -->
                            </div>
                            <div class="col-md-12">
                                <div class="single_form">
                                    <button class="main-btn">Send Massage</button>
                                </div> <!-- single form -->
                            </div>
                        </div> <!-- row -->
                    </form>
                </div> <!-- contact form -->
            </div>
            <div class="col-lg-4">
                <div class="contact_info pt-20">
                    <ul>
                        <li>
                            <div class="single_info d-flex align-items-center mt-30">
                                <div class="info_icon">
                                    <i class="fa fa-home"></i>
                                </div>
                                <div class="info_content media-body">
                                    <p>Bhubaneswar, <br> Odisha</p>
                                </div>
                            </div> <!-- single info -->
                        </li>
                        <li>
                            <div class="single_info d-flex align-items-center mt-30">
                                <div class="info_icon">
                                    <i class="fa fa-phone"></i>
                                </div>
                                <div class="info_content media-body">
                                    <p>+91 933 733 6750</p>
                                </div>
                            </div> <!-- single info -->
                        </li>
                        <li>
                            <div class="single_info d-flex align-items-center mt-30">
                                <div class="info_icon">
                                    <i class="fa fa-envelope"></i>
                                </div>
                                <div class="info_content media-body">
                                    <p>info@mytutorclasses.com</p>
                                </div>
                            </div> <!-- single info -->
                        </li>
                    </ul>
                </div> <!-- contact info -->
                
            </div>
        </div> <!-- row -->
    </div> <!-- container -->
</section>

<!--====== CONTACT PART ENDS ======-->
<?php include "includes/footer.php" ?>